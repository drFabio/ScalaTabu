Como compilar:
scalac  -d release Game.scala Payer.scala GameHall.scala Main.scala



